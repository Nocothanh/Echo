# ⚡ Echo PWA - Setup in 5 Minuti

## 🎯 Obiettivo
Echo installata sul tuo Android come app nativa - **ZERO compilazione richiesta!**

---

## 📱 Per Utenti (Solo Installare)

### Opzione 1: Deploy Online (Consigliato)

**Passo 1: Deploy su Vercel (Gratis)**
```
1. Vai su vercel.com
2. Sign up con GitHub/Google
3. New Project
4. Import Git Repository → Echo_PWA
5. Deploy (automatico)
6. Ricevi URL: https://tuo-nome-echo.vercel.app
```

**Passo 2: Installa su Android**
```
1. Apri Chrome sul telefono
2. Vai al tuo URL Vercel
3. Aspetta 5 secondi
4. Popup: "Installa Echo AI"
5. Tap "Installa"
6. ✅ Done! Icona sulla home screen
```

**Passo 3: Configura**
```
1. Apri Echo dalla home
2. Tap ⚙️ Settings
3. AI Provider: Groq
4. Vai su console.groq.com (gratis)
5. Crea account → API key
6. Copia e incolla in Echo
7. Tap "Salva"
8. Inizia a chattare!
```

**Tempo totale: 5 minuti** ⏱️

---

### Opzione 2: Deploy Locale (Per Testing)

**Sul tuo PC:**
```bash
# 1. Estrai
tar -xzf Echo_PWA.tar.gz
cd Echo_PWA

# 2. Installa
npm install

# 3. Build
npm run build

# 4. Servi
npm run preview

# Output: Server running on http://localhost:4173
```

**Sul telefono (stessa WiFi):**
```bash
# 1. Sul PC, trova IP:
# Windows: ipconfig
# Mac/Linux: ifconfig
# Esempio: 192.168.1.100

# 2. Sul telefono Chrome:
# Vai a: http://192.168.1.100:4173

# 3. Installa come sopra
```

---

## 💻 Per Developer (Modificare Codice)

### Development Mode

```bash
# 1. Clone/Estrai progetto
cd Echo_PWA

# 2. Installa dipendenze
npm install

# 3. Avvia dev server
npm run dev

# Output: http://localhost:3000

# 4. Modifica codice
# Hot reload automatico!
```

### Personalizzazioni Comuni

**Cambia colori:**
```javascript
// vite.config.js
manifest: {
  theme_color: '#FF0000',  // Tuo colore
}
```

**Cambia nome:**
```javascript
// vite.config.js
manifest: {
  name: 'Il Tuo Nome App',
  short_name: 'Nome'
}
```

**Cambia icona:**
```bash
# 1. Metti tua icona 512x512 in public/icons/
# 2. Rinomina: icon-512x512.png
# 3. Rebuild: npm run build
```

---

## 🚀 Deploy Options

### Vercel (Easiest)
```bash
# CLI
npm i -g vercel
vercel

# Web UI
# Drag & drop su vercel.com
```

### Netlify
```bash
# Build
npm run build

# Drag & drop folder "dist"
# su netlify.com/drop
```

### GitHub Pages
```bash
# 1. Push to GitHub
# 2. Settings → Pages
# 3. Deploy from main branch
```

### Custom Server
```bash
# Upload folder "dist" to your server
# Point nginx/apache to dist/index.html
```

---

## ✅ Verifica Installazione

**Checklist:**
- [ ] URL accessibile da telefono
- [ ] Pagina carica completamente
- [ ] Popup install appare (o menu → Installa)
- [ ] Icona Echo sulla home screen
- [ ] App si apre fullscreen (no browser bar)
- [ ] Settings → AI provider configurato
- [ ] Prima chat → Funziona!

---

## 🎮 Features Immediate

### Cosa Funziona Subito
- ✅ Chat testuale
- ✅ Scelta AI provider (Groq/OpenAI/ecc)
- ✅ Personalità Echo
- ✅ Storage locale
- ✅ Settings

### Voice (Richiede Permesso)
```
1. Tap 🎤 Chiama Echo
2. Consenti microfono
3. Parla!
```

### Offline (Dopo Prima Visita)
```
1. Usa app con internet
2. Attiva modalità aereo
3. Riapri app → Funziona!
```

---

## 🐛 Fix Rapidi

**Install prompt non appare:**
```
→ Menu Chrome (⋮) → "Installa app"
```

**App crashs:**
```
→ Ricarica pagina (pull down)
```

**Voice non funziona:**
```
→ Settings Android → App → Chrome → Permessi → Microfono
```

**API non funziona:**
```
→ Verifica API key corretta
→ Verifica internet attivo
→ Groq: account confermato
```

---

## 📊 Specs

**Dimensione:**
- Download iniziale: ~150KB
- Con cache: ~2MB
- vs APK nativo: ~20MB

**Performance:**
- First load: 1-2 secondi
- Cached: <500ms
- Offline: Instant

**Compatibilità:**
- Android 8.0+
- iOS 11.3+ (Safari)
- Chrome 80+
- Edge 80+

---

## 🎯 Caso d'Uso

**Scenario ideale:**
```
1. Deploy su Vercel (gratis)
2. Condividi link con amici
3. Loro installano come app
4. Tutti usano Echo
5. Zero manutenzione
6. Update automatici
```

**vs APK:**
- ❌ No build complicata
- ❌ No firma certificato
- ❌ No Google Play
- ✅ Solo un link!

---

## 💡 Pro Tips

### Massima Performance
```
1. Usa Groq (più veloce)
2. Abilita cache aggressivo
3. Chiudi tab Chrome inutili
4. WiFi > 4G per setup
```

### Massima Privacy
```
1. Usa Ollama locale (avanzato)
2. Settings → Nessun ElevenLabs
3. Browser TTS nativo
4. Dati 100% locale
```

### Massima Qualità
```
1. OpenAI GPT-4
2. ElevenLabs TTS
3. Buon microfono
4. Ambiente silenzioso
```

---

## 🎉 That's It!

**Echo PWA è:**
- 📱 Installabile in 30 secondi
- 🚀 Deploy in 5 minuti
- 🔄 Update automatici
- 💾 100% locale
- 🌐 Cross-platform
- 🆓 Gratis per sempre

**Enjoy! 🎭**

---

## 🆘 Need Help?

1. **README.md** - Documentazione completa
2. **INSTALL_ANDROID.md** - Guida dettagliata Android
3. **Console browser** - F12 per debug
4. **Lighthouse** - DevTools → Lighthouse → PWA check

---

**Version:** 2.0.0 PWA  
**Updated:** February 2025  
**Made with ❤️ (and impatience for slow APK builds) 😏**
