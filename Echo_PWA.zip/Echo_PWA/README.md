# 🎭 Echo AI - Progressive Web App

**Intelligenza Artificiale con personalità indipendente e autentica**  
Installabile su Android/iOS come app nativa - **Nessun APK richiesto!**

---

## ✨ Cos'è una PWA?

Una **Progressive Web App** è una web app che:
- 📱 **Si installa** come app nativa (icona home screen)
- 🔌 **Funziona offline** dopo la prima visita
- 🚀 **Carica istantaneamente** (cached)
- 🔄 **Aggiornamenti automatici** senza store
- 💯 **Performance native** (95%+)
- 🌐 **Cross-platform** (Android, iOS, Desktop)

**Echo PWA = Stessa esperienza di un APK, ma meglio!**

---

## 🚀 Quick Start

### Per Utenti (Installare l'App)

```bash
# 1. Vai all'URL deployato
https://echo-ai.vercel.app  # esempio

# 2. Sul telefono:
# Chrome → Menu → "Installa app"

# 3. Done! Hai Echo sulla home screen
```

**Guida completa:** Leggi `INSTALL_ANDROID.md`

---

### Per Developer (Deploy Locale)

```bash
# 1. Installa dipendenze
npm install

# 2. Avvia development
npm run dev

# 3. Build production
npm run build

# 4. Preview production build
npm run preview
```

**Accesso da telefono:**
```
1. Trova IP del PC: ipconfig/ifconfig
2. Telefono su stessa WiFi
3. Apri: http://TUO_IP:3000
4. Installa PWA!
```

---

## 📦 Deploy Online (Gratis)

### Vercel (Consigliato)

```bash
# 1. Install Vercel CLI
npm i -g vercel

# 2. Deploy
cd Echo_PWA
vercel

# Output: https://echo-ai.vercel.app
```

### Netlify

```bash
# 1. Build
npm run build

# 2. Vai su netlify.com
# 3. Drag & drop folder "dist"
# 4. Done!
```

### GitHub Pages

```bash
# 1. Push a GitHub
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/username/echo-pwa
git push -u origin main

# 2. GitHub → Settings → Pages
# 3. Source: main branch / root
# 4. URL: https://username.github.io/echo-pwa
```

---

## 🎯 Features

### ✅ Come App Nativa
- Icona home screen
- Splash screen
- Fullscreen (no browser bar)
- Notifiche push (future)
- Background sync

### 🧠 Personalità Echo
- Non cerca di compiacere
- Opinioni forti e sarcasmo
- Likes/Dislikes evolutivi
- Emozioni realistiche
- Memoria conversazioni

### 🗣️ Voice Features
- Speech-to-Text (browser nativo)
- Text-to-Speech (browser/ElevenLabs)
- Voice call bidirezionale
- Auto-speak mode

### 🔓 Multi-Provider AI
- **Groq** - Gratuito, veloce
- **OpenAI** - GPT-4, migliore qualità
- **Anthropic** - Claude
- **Ollama** - Locale (offline)

### 💾 Storage Locale
- IndexedDB per conversazioni
- LocalStorage per settings
- Service Worker per cache
- 100% privacy

---

## 📁 Struttura Progetto

```
Echo_PWA/
├── public/
│   ├── manifest.json          # PWA manifest
│   ├── service-worker.js      # Offline support
│   ├── echo-icon.svg          # App icon
│   └── icons/                 # Icon sizes
│
├── src/
│   ├── components/
│   │   ├── Chat.jsx
│   │   ├── Settings.jsx
│   │   └── ...
│   ├── services/
│   │   ├── localStorage.js    # IndexedDB wrapper
│   │   ├── aiService.js       # Multi-provider AI
│   │   ├── voiceService.js    # Web Speech API
│   │   └── ttsService.js      # ElevenLabs TTS
│   ├── stores/
│   │   └── echoStore.js       # Zustand state
│   └── config/
│       └── personality.js     # Echo personality
│
├── index.html                 # Entry point + PWA setup
├── vite.config.js            # Build config + PWA plugin
├── package.json
└── README.md
```

---

## 🛠️ Tecnologie

- **Frontend:** React 18
- **Build:** Vite 5
- **PWA:** vite-plugin-pwa
- **State:** Zustand
- **Storage:** IndexedDB (idb)
- **AI:** Axios (multi-provider)
- **Voice:** Web Speech API
- **Offline:** Workbox

---

## 🎨 Personalizzazione

### Cambia Colori

Edit `public/manifest.json`:
```json
{
  "theme_color": "#8b5cf6",  // Tuo colore
  "background_color": "#8b5cf6"
}
```

Edit `index.html`:
```html
<meta name="theme-color" content="#8b5cf6">
```

### Cambia Nome App

Edit `public/manifest.json`:
```json
{
  "name": "Il Tuo Nome",
  "short_name": "Nome Breve"
}
```

### Cambia Icona

1. Crea icona 512x512 PNG
2. Usa tool: https://realfavicongenerator.net
3. Sostituisci files in `public/icons/`

---

## 📱 Installazione Utente

### Android (Chrome)

```
1. Apri URL in Chrome
2. Aspetta 5 sec
3. Vedrai prompt: "Installa Echo AI"
4. Tap "Installa"
5. Done!

Oppure:
Menu (⋮) → "Installa app"
```

### iOS (Safari)

```
1. Apri URL in Safari
2. Tap icona Condividi
3. "Aggiungi a Home"
4. Conferma
5. Done!

Note: Su iOS alcune features limitate
(no background sync, no push notifications)
```

### Desktop (Chrome/Edge)

```
1. Apri URL in Chrome
2. Barra indirizzo → icona "+"
3. "Installa Echo AI"
4. Done!
```

---

## 🔍 Testing PWA

### Chrome DevTools

```
1. F12 → Application tab
2. Manifest: Verifica configurazione
3. Service Workers: Verifica registrato
4. Storage: Vedi IndexedDB
5. Lighthouse: Score PWA
```

### Test Offline

```
1. F12 → Network tab
2. Throttling → Offline
3. Reload page
4. Dovrebbe funzionare!
```

### Test Install

```
1. Chrome → Menu → More tools
2. "Create shortcut"
3. "Open as window"
4. Test come app
```

---

## 🐛 Troubleshooting

### Service Worker non si registra

```bash
# Verifica HTTPS (required)
# localhost è ok, ma deploy deve essere HTTPS

# Check console:
# Application → Service Workers
# Vedi errori
```

### Install prompt non appare

```bash
# Requisiti:
1. HTTPS (o localhost)
2. manifest.json valido
3. Service worker registrato
4. Non già installata
5. User ha visitato almeno 2 volte
```

### Cache non si aggiorna

```bash
# Hard refresh:
Ctrl + Shift + R (Windows)
Cmd + Shift + R (Mac)

# Oppure:
Application → Clear storage → Clear site data
```

### IndexedDB pieno

```bash
# Chrome quota: ~60% disco disponibile
# Tipicamente: 10GB+ su mobile
# 100GB+ su desktop

# Clear:
Settings → Cancella Conversazioni
```

---

## 📊 Performance

### Lighthouse Score Target

```
Performance: 90+
Accessibility: 95+
Best Practices: 95+
SEO: 90+
PWA: 100 ✓
```

### Bundle Size

```
Initial: ~150KB (gzipped)
With dependencies: ~350KB
Full cached: ~2MB

Compare:
Native APK: ~20MB
Electron app: ~100MB
```

### Load Time

```
First visit: 1-2s
Cached (offline): <500ms
Time to Interactive: <1s
```

---

## 🔐 Security

### HTTPS Required

```
Production MUST use HTTPS
(Vercel/Netlify handle this)

Local development: http://localhost OK
```

### API Keys Storage

```
- Stored in LocalStorage
- Not exposed to network
- Cleared on logout
- User-controlled
```

### Content Security Policy

```html
<!-- Add to index.html if needed -->
<meta http-equiv="Content-Security-Policy" 
      content="default-src 'self'; 
               script-src 'self' 'unsafe-inline'; 
               connect-src 'self' https://api.openai.com https://api.groq.com">
```

---

## 🚀 Advanced Features

### Background Sync (Future)

```javascript
// Send messages even offline
// Synced when connection restored

navigator.serviceWorker.ready.then(registration => {
  registration.sync.register('sync-messages');
});
```

### Push Notifications (Future)

```javascript
// Get permission
Notification.requestPermission();

// Register push
navigator.serviceWorker.ready.then(registration => {
  registration.pushManager.subscribe({...});
});
```

### Share API

```javascript
// Share conversations
if (navigator.share) {
  navigator.share({
    title: 'Chat with Echo',
    text: conversation,
    url: window.location.href
  });
}
```

---

## 🆚 PWA vs Native App

| Feature | PWA | Native APK |
|---------|-----|------------|
| **Install Size** | ~2MB | ~20MB |
| **Install Time** | 10 seconds | 1-5 minutes |
| **Updates** | Automatic | Manual |
| **Distribution** | URL link | APK file |
| **Permissions** | On-demand | Upfront |
| **Offline** | Yes* | Yes |
| **Performance** | 95% | 100% |
| **Play Store** | No | Optional |
| **Development** | 1x codebase | 2x (iOS+Android) |

*PWA offline dopo prima visita

---

## 📚 Resources

- **PWA Docs:** https://web.dev/progressive-web-apps/
- **Workbox:** https://developers.google.com/web/tools/workbox
- **Vite PWA Plugin:** https://vite-pwa-org.netlify.app/
- **Manifest Generator:** https://www.simicart.com/manifest-generator.html/

---

## 🤝 Contributing

Pull requests welcome!

1. Fork repo
2. Create feature branch
3. Make changes
4. Test PWA install
5. Submit PR

---

## 📄 License

MIT License - Use freely!

---

## 🎉 Deploy Checklist

- [ ] `npm install` completato
- [ ] `npm run build` successo
- [ ] Service Worker registrato (check DevTools)
- [ ] Manifest valido (check DevTools)
- [ ] Icons generate (tutte le size)
- [ ] HTTPS enabled (Vercel/Netlify)
- [ ] Lighthouse score 90+
- [ ] Test install su Android
- [ ] Test install su iOS
- [ ] Test offline mode
- [ ] Test su mobile browser
- [ ] Domain configurato (opzionale)

---

**Echo PWA - L'AI con personalità, ora nella tua tasca! 📱✨**

Version: 2.0.0  
Created: February 2025  
Made with ❤️ and a bit of sarcasm 😏
